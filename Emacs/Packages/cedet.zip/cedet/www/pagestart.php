<!-- -*- html -*- -->
<body bgcolor="white" text="black">
<style>
<!--
ol,ul,p,body,td,tr,th,form {font-family : helvetica,sans-serif; } 

table.BAR { background-color: #bfbfbf; border-top: medium solid black; border-bottom: medium solid black; }
table.DATA { background-color: #fafafa; border-collapse: collapse; border-top: solid black 2px; border-bottom: solid black 2px; border-left: solid black 2px; border-right: solid black 2px; }
tr.DATA { background-color: #dddddd;}
th { border-right: solid black 1px;  padding: 5px;}
tr.EVEN { background-color: #eeeeee;}


td.BAR { background-color: #bfbfbf; }
tt { font-family : courier }
pre { background-color: #dfdfdf; font-family : courier }

table.SPEEDBAR { background-color: none; border: medium solid black}

A:visited { color: #0000A0 ; text-decoration: none }
A:link { color: #0000F0 ; text-decoration: none }
A:active { color: #FF0000 ; text-decoration: underline overline }
A[href]:visited.sb { color: #0000A0 ; text-decoration: none; font-family : courier }
A[href]:link.SB { text-decoration: none; font-family : courier }
A[href]:hover.SB { background-color: orange ; text-decoration: none ; font-family : courier}
A[href]:hover { text-decoration: underline overline }
-->
</style>

<!--table><tr><td width="90%"><img src="cedetlogo.png" ></td>
<td><img src="writecode.png" align="right"></td></tr></table-->
<table cellspacing="0" border="0" width="100%"><tr>
   <td background="img-gen/cedet-logo-left.png" width="779" height="225">&nbsp;</td>
   <td background="img-gen/cedet-logo-middle.png" height="225">&nbsp;</td>
   <td background="img-gen/cedet-logo-right.png" width="27" height="225">&nbsp;</td>
</table>


<table border="0">
<tr><td valign="top">
<?php include ("rightcol.php") ?></td>
<td valign="top">

